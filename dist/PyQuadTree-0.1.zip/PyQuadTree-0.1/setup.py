try: from setuptools import setup
except: from distutils.core import setup

setup(	long_description=open("README.rst").read(), 
	name="""PyQuadTree""",
	license="""MIT""",
	author="""Karim Bahgat""",
	version="""0.1""",
	packages=['pyqtree'],
	classifiers=['Topic :: Scientific/Engineering :: GIS'],
	description="""A pure Python QuadTree spatial index for GIS or rendering usage.""",
	)
