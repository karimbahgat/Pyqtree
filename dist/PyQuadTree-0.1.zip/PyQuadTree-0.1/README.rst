PyQuadTree
==========

**Author:** Karim Bahgat, 2014

**Version:** 0.2

**License:** MIT

**Platforms:** Python 2x and 3x

Based on Matt Rasmussen's original code:
https://github.com/mdrasmus/compbio/blob/master/rasmus/quadtree.py

Introduction
------------

PyQuadTree is a pure Python spatial index for GIS or rendering usage.
Useful for maps composed of tiles, as in online map serving.

Getting Started
---------------

Dependencies
~~~~~~~~~~~~

None

Installing It
~~~~~~~~~~~~~

Installing PyQuadTree can be done by typing "pip install pyqtree" in
your terminal or commandline. Alternatively, you can simply download the
"pyqtree" folder and place it anywhere Python can import it, such as the
folder "PythonXX/Lib/site-packages".

Example Usage
-------------

Start your session by importing the module.

.. code:: python

    import pyqtree

Setup the spatial index, giving it a bounding box area to keep track of.
The bounding box being in a four-tuple: (xmin,ymin,xmax,ymax).

.. code:: python

    spindex = pyqtree.Index(bbox=[0,0,100,100])

Populate the index with items that you want to be retrieved at a later
point, along with each item's geographic bbox.

.. code:: python

    #this example assumes you have a list of items with bbox attribute
    for item in items:
        spindex.insert(item=item, bbox=item.bbox)

Then when you have a region of interest and you wish to retrieve items
from that region, just use the index's intersect method. This quickly
gives you a list of the stored items whose bboxes intersects your region
of interests.

.. code:: python

    overlapbbox = (51,51,86,86)
    matches = spindex.intersect(overlapbbox)

There are other things that can be done as well, but that's it for the
main usage!
